## CS-331 Assignment 1 (Java)
### Tejas Khairnar 
### Roll Number : 180101081
Running the Code in a linux based system:

1. Make sure Java is installed on your machine.
2. Open the terminal and change the directory to the directory of the source ( .java file) code.
3. Type ```javac <Program_Name>.java``` in the terminal and press enter to compile your code. 
4. Now, type ```java <Program_Name> <number_of_threads_as_argument>``` in the terminal and press enter to run the program.
5. If the number of threads is not between 4 and 16 the output console will print an error message.  

NOTE :  All the instructions are also given in each source code file.