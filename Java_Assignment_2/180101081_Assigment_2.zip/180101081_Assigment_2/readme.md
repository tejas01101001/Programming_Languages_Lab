## CS-331 Assignment 2 (Java)
### Tejas Khairnar 
### Roll Number : 180101081

Running the Code in a linux based system:

1. Make sure Java is installed on your machine.
2. Open the terminal and change the directory to the directory of the source ( .java file) code.
3. Type ```javac <Program_Name>.java``` in the terminal and press enter to compile your code. 
4. Now, type ```java <Program_Name> <number_of_updaters_per_transaction>``` in the terminal and press enter to run the program.
5. Once the program starts running a file "Data.txt" is created wherein all transactions are present.
6. Ignore any warnings if present.

NOTE :  All the instructions are also given in the source code file.